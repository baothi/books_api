import { Field, Formik, yup, TextArea } from "./Formik";
import CheckBox from "./CheckBox";
const UI = {
  Field,
  Formik,
  yup,
  CheckBox,
  TextArea,
};
export { UI };
