export const StorageKey = {
  SHOPPING_CARTS: "SHOPPING_CARTS",
  USER_TOKEN: "USER_TOKEN",
};
