import rectangleLogo from "../assets/images/logo/logo.png";
import circleLogo from "../assets/images/logo/logo.png";
import userAvatar from "../assets/images/userAvatar.png";
import upload from "../assets/images/upload.jpg";
import bg_img from "../assets/images/vuexy-login-bg.jpg";
import img_login from "../assets/images/login.png";

const IMAGES = {
  rectangleLogo,
  circleLogo,
  userAvatar,
  upload,
  bg_img,
  img_login,
};

export default IMAGES;
