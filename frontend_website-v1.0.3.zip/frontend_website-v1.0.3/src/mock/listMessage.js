let listMessage = [
  {
    id: 0,
    type: "SUCCESS",
    title: "You have new order!",
    content:
      "Are your going to meet me tonight, Sesame snaps lollipop macaroon croissant cheesecake pastry cupcake.",
    time: "9 hours ago",
    position: [{ value: "frontend" }, { value: "backend" }, { value: "doc" }],
  },
  {
    id: 1,
    type: "SUCCESS",
    title: "You are Awsome!",
    content:
      "You got new order, now, Sesame snaps lollipop macaroon croissant cheesecake pastry cupcake.",
    time: "1 hours ago",
    position: [{ value: "frontend" }, { value: "doc" }],
  },
  {
    id: 2,
    type: "WARNING",
    title: "Please check mail to update!",
    content:
      "John Dan just send you 2 email, Sesame snaps lollipop macaroon croissant cheesecake pastry cupcake.",
    time: "2 minute ago",
    position: [{ value: "frontend" }, { value: "backend" }, { value: "doc" }],
  },
  {
    id: 3,
    type: "SUCCESS",
    title: "Chocolate in valentine day",
    content:
      "Food for valentine day so good, Sesame snaps lollipop macaroon croissant cheesecake pastry cupcake.",
    time: "1 day ogo",
    position: [
      { value: "frontend" },
      { value: "backend" },
      { value: "doc" },
      { value: "bug" },
    ],
  },
  {
    id: 4,
    type: "ERORR",
    title: "Erorr the task to fix",
    content:
      "Server have 99% CPU, Sesame snaps lollipop macaroon croissant cheesecake pastry cupcake.",
    time: "Today",
    position: [{ value: "bug" }],
  },
  {
    id: 5,
    type: "SUCCESS",
    title: "You are Awsome!",
    content:
      "You got new order, now, Sesame snaps lollipop macaroon croissant cheesecake pastry cupcake.",
    time: "1 hours ago",
    position: [{ value: "frontend" }, { value: "backend" }, { value: "doc" }],
  },
  {
    id: 6,
    type: "WARNING",
    title: "How are you doing, today",
    content:
      "Do you need a friend ?, Sesame snaps lollipop macaroon croissant cheesecake pastry cupcake.",
    time: "Just now",
    position: [{ value: "frontend" }, { value: "backend" }, { value: "doc" }],
  },
  {
    id: 7,
    type: "ERORR",
    title: "Erorr the task to fix",
    content:
      "Server have 99% CPU, Sesame snaps lollipop macaroon croissant cheesecake pastry cupcake.",
    time: "Today",
    position: [{ value: "frontend" }, { value: "backend" }],
  },
];

export { listMessage };
