# from django.contrib import admin

# class PostAdmin(admin.ModelAdmin):
#   list_display = (
#     'id',
#     'title',
#     'workingtime',
#     'created_at',
#     'updated_at',
#   )
#   list_display_links = ('id', 'title')
#   empty_value_display = '--empty--'
