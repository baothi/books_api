# from django.contrib import admin

# class TicketAdmin(admin.ModelAdmin):
#   list_display = (
#     'id',
#     'title',
#     'customer',
#     'product',
#     'priority',
#     'mobile_number',
#     'description',
#     'ticket_type',
#     'verify_code',
#     'status'
#   )
#   list_display_links = ('id', 'title')
#   empty_value_display = '--empty--'
