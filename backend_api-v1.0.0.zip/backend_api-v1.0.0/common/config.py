

ACCOUNT_EMPTY = {
  "CODE": '1001',
  "MESSAGE": 'Username and password can\'t be empty.'
},
USERNAME_FAIL = {
  "CODE": '1002',
  "MESSAGE": 'Account not found.'
},
PASSWORD_FAIL = {
  "CODE": '1003',
  "MESSAGE": 'Password is wrong'
}
